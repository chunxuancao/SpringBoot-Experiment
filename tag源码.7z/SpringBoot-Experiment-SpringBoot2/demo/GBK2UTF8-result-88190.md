# Process result (7)

> item format: [encoding/confidence][file path]

## Converted (0)


## Not convert (7)

- `[UTF-8/0.99]` `e:\Personal blog\SpringBoot\demo\src\main\resources\application-dev.properties`
- `[UTF-8/0.99]` `e:\Personal blog\SpringBoot\demo\src\main\resources\application-prod.properties`
- `[UTF-8/0.99]` `e:\Personal blog\SpringBoot\demo\src\main\resources\application-test.properties`
- `[UTF-8/0.99]` `e:\Personal blog\SpringBoot\demo\src\main\resources\application.properties`
- `[ascii/1]` `e:\Personal blog\SpringBoot\demo\src\main\resources\application.yaml`
- `[ascii/1]` `e:\Personal blog\SpringBoot\demo\src\main\resources\beans.xml`
- `[ascii/1]` `e:\Personal blog\SpringBoot\demo\src\main\resources\test.properties`
