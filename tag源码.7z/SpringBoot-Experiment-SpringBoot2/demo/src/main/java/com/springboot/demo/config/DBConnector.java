package com.springboot.demo.config;

public interface DBConnector {
    public void configure();
}
